```python
import warnings
warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn import linear_model
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.metrics import mean_squared_error, r2_score
from mlxtend.feature_selection import SequentialFeatureSelector as SFS
```


```python
#Importing Dataset
data = pd.read_csv("D:/PARTH SHAH/R/ALY 6020/Module 2 Project/car.csv", na_values=['?'])
data.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MPG</th>
      <th>Cylinders</th>
      <th>Displacement</th>
      <th>Horsepower</th>
      <th>Weight</th>
      <th>Acceleration</th>
      <th>Model Year</th>
      <th>US Made</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>18.0</td>
      <td>8</td>
      <td>307.0</td>
      <td>130.0</td>
      <td>3504</td>
      <td>12.0</td>
      <td>70</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>15.0</td>
      <td>8</td>
      <td>350.0</td>
      <td>165.0</td>
      <td>3693</td>
      <td>11.5</td>
      <td>70</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>18.0</td>
      <td>8</td>
      <td>318.0</td>
      <td>150.0</td>
      <td>3436</td>
      <td>11.0</td>
      <td>70</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>16.0</td>
      <td>8</td>
      <td>304.0</td>
      <td>150.0</td>
      <td>3433</td>
      <td>12.0</td>
      <td>70</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>17.0</td>
      <td>8</td>
      <td>302.0</td>
      <td>140.0</td>
      <td>3449</td>
      <td>10.5</td>
      <td>70</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Checking Null Values
data.isnull().sum()
```




    MPG             0
    Cylinders       0
    Displacement    0
    Horsepower      6
    Weight          0
    Acceleration    0
    Model Year      0
    US Made         0
    dtype: int64




```python
data['Horsepower'].unique()
```




    array([130., 165., 150., 140., 198., 220., 215., 225., 190., 170., 160.,
            95.,  97.,  85.,  88.,  46.,  87.,  90., 113., 200., 210., 193.,
            nan, 100., 105., 175., 153., 180., 110.,  72.,  86.,  70.,  76.,
            65.,  69.,  60.,  80.,  54., 208., 155., 112.,  92., 145., 137.,
           158., 167.,  94., 107., 230.,  49.,  75.,  91., 122.,  67.,  83.,
            78.,  52.,  61.,  93., 148., 129.,  96.,  71.,  98., 115.,  53.,
            81.,  79., 120., 152., 102., 108.,  68.,  58., 149.,  89.,  63.,
            48.,  66., 139., 103., 125., 133., 138., 135., 142.,  77.,  62.,
           132.,  84.,  64.,  74., 116.,  82.])




```python
data.loc[data.Horsepower=='NaN']
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MPG</th>
      <th>Cylinders</th>
      <th>Displacement</th>
      <th>Horsepower</th>
      <th>Weight</th>
      <th>Acceleration</th>
      <th>Model Year</th>
      <th>US Made</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>18.0</td>
      <td>8</td>
      <td>307.0</td>
      <td>130.0</td>
      <td>3504</td>
      <td>12.0</td>
      <td>70</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>15.0</td>
      <td>8</td>
      <td>350.0</td>
      <td>165.0</td>
      <td>3693</td>
      <td>11.5</td>
      <td>70</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>18.0</td>
      <td>8</td>
      <td>318.0</td>
      <td>150.0</td>
      <td>3436</td>
      <td>11.0</td>
      <td>70</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>16.0</td>
      <td>8</td>
      <td>304.0</td>
      <td>150.0</td>
      <td>3433</td>
      <td>12.0</td>
      <td>70</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>17.0</td>
      <td>8</td>
      <td>302.0</td>
      <td>140.0</td>
      <td>3449</td>
      <td>10.5</td>
      <td>70</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Mean
average = data['Horsepower'].mean()
average
```




    104.46938775510205




```python
#Fill mean values
data['Horsepower'].fillna(average, inplace=True)
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MPG</th>
      <th>Cylinders</th>
      <th>Displacement</th>
      <th>Horsepower</th>
      <th>Weight</th>
      <th>Acceleration</th>
      <th>Model Year</th>
      <th>US Made</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>18.0</td>
      <td>8</td>
      <td>307.0</td>
      <td>130.0</td>
      <td>3504</td>
      <td>12.0</td>
      <td>70</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>15.0</td>
      <td>8</td>
      <td>350.0</td>
      <td>165.0</td>
      <td>3693</td>
      <td>11.5</td>
      <td>70</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>18.0</td>
      <td>8</td>
      <td>318.0</td>
      <td>150.0</td>
      <td>3436</td>
      <td>11.0</td>
      <td>70</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>16.0</td>
      <td>8</td>
      <td>304.0</td>
      <td>150.0</td>
      <td>3433</td>
      <td>12.0</td>
      <td>70</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>17.0</td>
      <td>8</td>
      <td>302.0</td>
      <td>140.0</td>
      <td>3449</td>
      <td>10.5</td>
      <td>70</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MPG</th>
      <th>Cylinders</th>
      <th>Displacement</th>
      <th>Horsepower</th>
      <th>Weight</th>
      <th>Acceleration</th>
      <th>Model Year</th>
      <th>US Made</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>398.000000</td>
      <td>398.000000</td>
      <td>398.000000</td>
      <td>398.000000</td>
      <td>398.000000</td>
      <td>398.000000</td>
      <td>398.000000</td>
      <td>398.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>23.514573</td>
      <td>5.454774</td>
      <td>193.425879</td>
      <td>104.469388</td>
      <td>2970.424623</td>
      <td>15.568090</td>
      <td>76.010050</td>
      <td>0.625628</td>
    </tr>
    <tr>
      <th>std</th>
      <td>7.815984</td>
      <td>1.701004</td>
      <td>104.269838</td>
      <td>38.199187</td>
      <td>846.841774</td>
      <td>2.757689</td>
      <td>3.697627</td>
      <td>0.484569</td>
    </tr>
    <tr>
      <th>min</th>
      <td>9.000000</td>
      <td>3.000000</td>
      <td>68.000000</td>
      <td>46.000000</td>
      <td>1613.000000</td>
      <td>8.000000</td>
      <td>70.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>17.500000</td>
      <td>4.000000</td>
      <td>104.250000</td>
      <td>76.000000</td>
      <td>2223.750000</td>
      <td>13.825000</td>
      <td>73.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>23.000000</td>
      <td>4.000000</td>
      <td>148.500000</td>
      <td>95.000000</td>
      <td>2803.500000</td>
      <td>15.500000</td>
      <td>76.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>29.000000</td>
      <td>8.000000</td>
      <td>262.000000</td>
      <td>125.000000</td>
      <td>3608.000000</td>
      <td>17.175000</td>
      <td>79.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>46.600000</td>
      <td>8.000000</td>
      <td>455.000000</td>
      <td>230.000000</td>
      <td>5140.000000</td>
      <td>24.800000</td>
      <td>82.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Distribution of MPG
sns.displot(data["MPG"], kde = True)
```




    <seaborn.axisgrid.FacetGrid at 0x27de8f1b0a0>




    
![png](output_8_1.png)
    



```python
#Correlation Plot
plt.figure(figsize = (20,10))  
sns.heatmap(data.corr(),cmap="GnBu",annot = True)
```




    <AxesSubplot:>




    
![png](output_9_1.png)
    



```python
#splitting dataset
x = data.iloc[:,1:8]
y = data[['MPG']]

x_train,x_test, y_train,y_test=train_test_split(x,y, test_size=0.20, random_state=11)
```


```python
#Linear regerssion
lm = LinearRegression()
sfs = SFS(lm,
          k_features = 7,
          forward = True,
          floating = False,
          scoring = "r2",
          cv=5,
          n_jobs=-1)

sfs = sfs.fit(x_train,y_train)
sfs

pd.DataFrame.from_dict(sfs.get_metric_dict()).T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>feature_idx</th>
      <th>cv_scores</th>
      <th>avg_score</th>
      <th>feature_names</th>
      <th>ci_bound</th>
      <th>std_dev</th>
      <th>std_err</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>(3,)</td>
      <td>[0.7514950539171075, 0.6899351490270255, 0.695...</td>
      <td>0.702195</td>
      <td>(Weight,)</td>
      <td>0.035296</td>
      <td>0.027462</td>
      <td>0.013731</td>
    </tr>
    <tr>
      <th>2</th>
      <td>(3, 5)</td>
      <td>[0.8423667663456691, 0.8078997374250196, 0.807...</td>
      <td>0.81061</td>
      <td>(Weight, Model Year)</td>
      <td>0.021932</td>
      <td>0.017064</td>
      <td>0.008532</td>
    </tr>
    <tr>
      <th>3</th>
      <td>(3, 5, 6)</td>
      <td>[0.8585577035793526, 0.819867964706962, 0.7977...</td>
      <td>0.819456</td>
      <td>(Weight, Model Year, US Made)</td>
      <td>0.027244</td>
      <td>0.021197</td>
      <td>0.010598</td>
    </tr>
    <tr>
      <th>4</th>
      <td>(1, 3, 5, 6)</td>
      <td>[0.8604162462029418, 0.8229943575175207, 0.801...</td>
      <td>0.822332</td>
      <td>(Displacement, Weight, Model Year, US Made)</td>
      <td>0.026227</td>
      <td>0.020406</td>
      <td>0.010203</td>
    </tr>
    <tr>
      <th>5</th>
      <td>(1, 2, 3, 5, 6)</td>
      <td>[0.860313423830177, 0.8148345859748004, 0.8019...</td>
      <td>0.821868</td>
      <td>(Displacement, Horsepower, Weight, Model Year,...</td>
      <td>0.026082</td>
      <td>0.020293</td>
      <td>0.010147</td>
    </tr>
    <tr>
      <th>6</th>
      <td>(1, 2, 3, 4, 5, 6)</td>
      <td>[0.8644098636268109, 0.8088911790378264, 0.796...</td>
      <td>0.8213</td>
      <td>(Displacement, Horsepower, Weight, Acceleratio...</td>
      <td>0.030102</td>
      <td>0.023421</td>
      <td>0.01171</td>
    </tr>
    <tr>
      <th>7</th>
      <td>(0, 1, 2, 3, 4, 5, 6)</td>
      <td>[0.8614543786498171, 0.8088819476681893, 0.794...</td>
      <td>0.819964</td>
      <td>(Cylinders, Displacement, Horsepower, Weight, ...</td>
      <td>0.029333</td>
      <td>0.022822</td>
      <td>0.011411</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Best Model
x = data[['Displacement', 'Horsepower','Weight','Model Year','US Made']]
y = data[['MPG']]

x_train,x_test, y_train,y_test=train_test_split(x,y, test_size=0.20, random_state=11)

x = sm.add_constant(x_train)
est = sm.OLS(y_train,x).fit()
print(est.summary()) 
```

                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:                    MPG   R-squared:                       0.829
    Model:                            OLS   Adj. R-squared:                  0.826
    Method:                 Least Squares   F-statistic:                     301.7
    Date:                Wed, 25 Jan 2023   Prob (F-statistic):          3.46e-117
    Time:                        22:35:46   Log-Likelihood:                -822.73
    No. Observations:                 318   AIC:                             1657.
    Df Residuals:                     312   BIC:                             1680.
    Df Model:                           5                                         
    Covariance Type:            nonrobust                                         
    ================================================================================
                       coef    std err          t      P>|t|      [0.025      0.975]
    --------------------------------------------------------------------------------
    const          -13.2685      4.418     -3.004      0.003     -21.961      -4.576
    Displacement     0.0184      0.006      2.947      0.003       0.006       0.031
    Horsepower      -0.0201      0.011     -1.774      0.077      -0.042       0.002
    Weight          -0.0070      0.001    -11.760      0.000      -0.008      -0.006
    Model Year       0.7613      0.056     13.640      0.000       0.651       0.871
    US Made         -2.7602      0.525     -5.259      0.000      -3.793      -1.728
    ==============================================================================
    Omnibus:                        9.158   Durbin-Watson:                   1.943
    Prob(Omnibus):                  0.010   Jarque-Bera (JB):               11.251
    Skew:                           0.268   Prob(JB):                      0.00361
    Kurtosis:                       3.750   Cond. No.                     7.52e+04
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
    [2] The condition number is large, 7.52e+04. This might indicate that there are
    strong multicollinearity or other numerical problems.
    


```python
#Accuracy of model
lm.fit(x_train, y_train)
lm.score(x_train,y_train)
```




    0.8286412766056341




```python
x = data[['Displacement','Weight','Model Year','US Made']]
y = data[['MPG']]

x_train,x_test, y_train,y_test=train_test_split(x,y, test_size=0.20, random_state=11)

x = sm.add_constant(x_train)
est = sm.OLS(y_train,x).fit()
print(est.summary()) 
```

                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:                    MPG   R-squared:                       0.827
    Model:                            OLS   Adj. R-squared:                  0.825
    Method:                 Least Squares   F-statistic:                     373.8
    Date:                Wed, 25 Jan 2023   Prob (F-statistic):          8.01e-118
    Time:                        22:09:56   Log-Likelihood:                -824.32
    No. Observations:                 318   AIC:                             1659.
    Df Residuals:                     313   BIC:                             1677.
    Df Model:                           4                                         
    Covariance Type:            nonrobust                                         
    ================================================================================
                       coef    std err          t      P>|t|      [0.025      0.975]
    --------------------------------------------------------------------------------
    const          -15.1514      4.303     -3.521      0.000     -23.618      -6.685
    Displacement     0.0125      0.005      2.356      0.019       0.002       0.023
    Weight          -0.0072      0.001    -12.152      0.000      -0.008      -0.006
    Model Year       0.7780      0.055     14.093      0.000       0.669       0.887
    US Made         -2.5034      0.506     -4.946      0.000      -3.499      -1.507
    ==============================================================================
    Omnibus:                       11.059   Durbin-Watson:                   1.941
    Prob(Omnibus):                  0.004   Jarque-Bera (JB):               16.140
    Skew:                           0.251   Prob(JB):                     0.000313
    Kurtosis:                       3.983   Cond. No.                     7.30e+04
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
    [2] The condition number is large, 7.3e+04. This might indicate that there are
    strong multicollinearity or other numerical problems.
    


```python

```
